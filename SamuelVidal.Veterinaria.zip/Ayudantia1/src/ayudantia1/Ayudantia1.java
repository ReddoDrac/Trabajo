/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ayudantia1;

import java.time.LocalDate;

/**
 *
 * @author samuv
 */
public class Ayudantia1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Cliente c1 = new Cliente("C0001", "Samuel", 20, LocalDate.of(2004, 7, 20));
        System.out.println("El nombre del cliente es : "+c1.getNombre());
        System.out.println("Su Id es : "+c1.getIdDelCliente());
        System.out.println("La Edad es : "+c1.getEdad());
        System.out.println("Su fecha de nacimineto es : "+c1.getFechaDeNacimiento());
        
    }
    
}
