/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ayudantia1;

import java.time.LocalDate;


/**
 *
 * @author samuv
 */
public class Cliente {
    private String idDelCliente;
    private String nombre;
    private int edad;
    private LocalDate fechaDeNacimiento;

    public Cliente() {
    }

    public Cliente(String idDelCliente, String nombre, int edad, LocalDate fechaDeNacimiento) {
        this.idDelCliente = idDelCliente;
        this.nombre = nombre;
        this.edad = edad;
        this.fechaDeNacimiento = fechaDeNacimiento;
    }

    public String getIdDelCliente() {
        return idDelCliente;
    }

    public void setIdDelCliente(String idDelCliente) {
        this.idDelCliente = idDelCliente;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public LocalDate getFechaDeNacimiento() {
        return fechaDeNacimiento;
    }

    public void setFechaDeNacimiento(LocalDate fechaDeNacimiento) {
        this.fechaDeNacimiento = fechaDeNacimiento;
    }

    @Override
    public String toString() {
        return "Cliente{" + "idDelCliente=" + idDelCliente + ", nombre=" + nombre + ", edad=" + edad + ", fechaDeNacimiento=" + fechaDeNacimiento + '}';
    }
    
    

}
    
   
